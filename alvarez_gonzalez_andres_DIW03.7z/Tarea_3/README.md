## TAREA para DIW03
# Enunciado

Una vez que ya tienes el diseño de la web planteado en la tarea de la unidad 2 es el momento de realizar tu primer prototipo en HTML y CSS. 
Siguiendo las pautas que tú mismo te has establecido en la tarea de la unidad 2 realiza un prototipo para tu web. en HTML y CSS. Deberás de respetar las siguientes condiciones:
Debes crear una cuenta de GitHub y crear un proyecto para que después se pueda subir a esta plataforma
Para la maquetación de la web debes utilizar flexbox. 
Debes incluir imágenes, vídeos y textos de ejemplo relacionados con la página, es decir, no vale poner "aquí va una imagen" o el típico texto lorem ipsum.
Todo el proyecto no puede superar los 100MB de espacio
Una vez realizada la web súbela a tu cuenta de GitHub. 
